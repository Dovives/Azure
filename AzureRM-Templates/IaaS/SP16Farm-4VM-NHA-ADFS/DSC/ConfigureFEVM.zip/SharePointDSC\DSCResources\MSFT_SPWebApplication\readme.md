# Description

This resource is responsible for creating a web application within the local
SharePoint farm. The resource will provision the web application with all of
the current settings, and then ensure that it stays part of the correct
application pool beyond that (additional checking and setting of properties
