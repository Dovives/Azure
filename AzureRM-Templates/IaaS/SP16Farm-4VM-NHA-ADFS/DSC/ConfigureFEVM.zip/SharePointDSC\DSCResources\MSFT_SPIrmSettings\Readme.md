# Description

This resource is used to manipulate the IRM settings in SharePoint, integrating
it with AD RMS
