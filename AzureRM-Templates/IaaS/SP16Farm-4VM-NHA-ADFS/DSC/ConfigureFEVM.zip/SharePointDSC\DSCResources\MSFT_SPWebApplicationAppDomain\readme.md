# Description

This resource will configure the App Domain at a specific zone for the given
Web Application. The configuration is done per zone on the specified web
application, allowing for the setting of unique app domains for each extension
of a web application. The app prefix should still be set using the SPAppDomain
resource before this is applied to customise a specific zone.
